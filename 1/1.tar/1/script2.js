'use strict'
let num

num = 1
num++
alert(num)